# PayTask — Flask survey website starter

## Quick start

```bash
python -m pip install -r requirements.txt
export SECRET_KEY='replace-with-a-long-random-secret'
python app.py
```
Open http://127.0.0.1:5000. On Windows PowerShell use `$env:SECRET_KEY='...'` instead of `export`.

## Rules
- KSh 50 signup promotional credit, **not cash** and not usable for withdrawal.
- Six categories with three sample surveys each; **first survey in each category is free**.
- Other surveys require a verified KSh 30 M-Pesa STK payment.
- One KSh 100 **demo earnings** entry per survey per account, credited only once.
- Withdrawal request minimum KSh 2,500 in demo earnings; amount is reserved immediately, request remains **pending**. There is **no automatic B2C payout**, and no operator approval/refund UI in this starter.

## M-Pesa configuration
Default `MPESA_MODE=demo`: no real charges or unlocks of paid surveys. For Safaricom Daraja integration, set:

```
MPESA_MODE=sandbox  # or production
MPESA_CONSUMER_KEY=...
MPESA_CONSUMER_SECRET=...
MPESA_SHORTCODE=...
MPESA_PASSKEY=...
MPESA_CALLBACK_URL=https://your-public-https-domain/mpesa/callback
```

Use Daraja sandbox credentials and test numbers first. In configured mode, users get an STK prompt, then click **Verify payment**; the backend queries Safaricom before unlocking. Callbacks alone do not unlock surveys because they are not trusted. Production requires HTTPS, secret management, audited transaction reconciliation, M-Pesa merchant onboarding, CSRF/rate limiting beyond this starter, customer support, terms, privacy compliance, fraud detection, and an approved payout/withdrawal process. Do not represent demo rewards as guaranteed withdrawable money. Paying for survey access can create consumer-protection and financial sustainability risks; disclose the terms and ensure funding for rewards before launch.

This is a development prototype, **not production-ready**.

## Admin dashboard

Set strong administrator credentials before starting the app:

```bash
export PAYTASK_ADMIN_USER='owner'
export PAYTASK_ADMIN_PASSWORD='use-a-long-unique-password'
```

Visit `/admin/login`. The dashboard shows users, survey completions, payment statuses, and withdrawal requests; it can add surveys, activate/deactivate surveys, reject withdrawal requests (restoring reserved demo earnings), or record a manually verified payout reference. **Recording a payout does not send money.** Never mark a payout paid until it has actually been sent and verified outside the app. Admin access is disabled unless both environment variables are set.

Before production, replace environment-password admin login with individual administrator accounts and MFA, add rate limits, stronger payout reconciliation and auditing, and arrange legitimate funding for survey rewards.
